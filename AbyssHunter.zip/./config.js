module.exports = {
  tokens: "8317840688:AAEiDH7oYzJv4wlHUpPeA2Pf9OD9c_jvv2Y",
  owner: "8459065155",
  port: "22",
  ipvps: "188.166.226.132:22"
};